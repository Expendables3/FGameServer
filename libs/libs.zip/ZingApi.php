<?php

// toantn
    require_once "zing/ZM_API_Common.php";


class ZingApi
{

	/**
	 * require api
	 * @param unknown_type $file
	 */
	static function require_api($file)
	{
		require_once "zing/".$file.".php";
	}
	/**
	 * get uid login zing me
	 * return int
	 */
	public static function getUserId()
	{
		$uId = 0;
		if(Controller::$session_key)
		{
			self::require_api('ZM_Sessions');
			$ZM_Sessions = new ZM_Sessions();
			$uId =  $ZM_Sessions->getLoggedInUser(Controller::$session_key);
		}
		return $uId;
	}

    /**
	 * Lay Id = User Name
	 * return int
	 */

    public static function getUserIdByUsername($userName)
    {
      self::require_api('ZM_Users');
	  $ZM_User = new ZM_Users();
      return $ZM_User->getUserIdByUsername($userName);
    }
	/**
	 * lay thong tin cua 1 danh sach user
	 * @param $uIds mang cac user id
	 * author : toannm
	 * 1/9/2010
	 */
	static function getUserInfo($uIds)
	{
		$sfields = "userid,username,displayname,tinyurl";
		self::require_api('ZM_Users');
		$ZM_User = new ZM_Users();
		$ufields = "";

        if(is_array($uIds))
        {
          	$i=1;
          	foreach($uIds as $vId=>$uId)
	    	{
			if($i == 1)
			{
				$ufields .= $uId;
			}
			else
			{
				$ufields .= ','.$uId;
			}
			$i++;
	    	}
        }
        else  $ufields = $uIds ;

		$infos = $ZM_User->getInfo($ufields,$sfields);
		return $infos;
	}
	/**
	 * lay danh sach id cua ban be
	 * toannm
	 * 1/9/2010
	 */
	static function getFriendList()
	{
		self::require_api('ZM_Friends');
		$ZM_Friend =  new ZM_Friends();
		$friends = $ZM_Friend->getLists(Controller::$session_key);
		return $friends;
	}
	/**
	 * ham lay toan bo uid cua ban be co choi ung dung
	 * toannm
	 * 1/9/2010
	 */
	static function getAppUsers()
	{
		self::require_api('ZM_Friends');
		$ZM_Friend =  new ZM_Friends();
		$users = $ZM_Friend->getAppUsers(Controller::$session_key);
		return $users;
	}
	/**
	 * ham feed len wall
	 * toannm
	 * 1/9/2010
	 */
	function feedWall($template_bundle_id,$template_data)
	{
		self::require_api('ZM_Feed');
		$ZM_Feed = new ZM_Feed();
		$result = $ZM_Feed->publishUserActionV2(Controller::$session_key,$template_bundle_id,$template_data);
		return $result;
	}
	/**
	 * notify
	 * toannm
	 * 1/9/2010
	 */
	function notifyFriend()
	{

	}

}