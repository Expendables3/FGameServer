<?php
class Services_ZM
{
	static public $apiURL = CON_apiURL;
    static public $apiKey = CON_apiKey;
    static public $secret = CON_secret;

    static public $timeout = 30;
}
?>